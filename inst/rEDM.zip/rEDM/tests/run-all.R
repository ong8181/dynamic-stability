library(testthat)
test_package("rEDM")
